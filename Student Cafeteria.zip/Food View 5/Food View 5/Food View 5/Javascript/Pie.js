﻿//reference form object in javascript
var theForm = document.forms["foodform"]

//Radio button calculations and ARRAY
var food_options = new Array();
food_options["1x"] = 16;
food_options["2x"] = 24;
food_options["3x"] = 27;
food_options["4x"] = 35;

// getFoodSizePrice() finds the price based on the size of the cake.
// Here, we need to take user's the selection from radio button selection
function getFoodSizePrice() {
    //get specific foodSizePrice
    var foodSizePrice = 0;
    //Get a reference to the form id="foodform"
    var theForm = document.forms["foodform"];
    //Get a reference to the food the user Chooses name=selectedFood":
    var selectedFood = theForm.elements["selectedfood"];
    //Here since there are 3 radio buttons selectedFood.length = 3
    //We loop through each radio buttons
    for (var i = 0; i < selectedFood.length; i++) {
        //if the radio button is checked
        if (selectedFood[i].checked) {
            //we set foodSizePrice to the value of the selected radio button
            //i.e. if the user choose the Medium we set it to 25
            //by using the food_options array
            //We get the selected Items value
            //For example food_options["Medium".value]"
            foodSizePrice = food_options[selectedFood[i].value];
            //If we get a match then we break out of this loop
            //No reason to continue if we get a match
            break;
        }
    }
    //We return the foodSizePrice
    return foodSizePrice;
}

//ARRAY Price for Drop-Down List
var quantity_prices = new Array();
quantity_prices["None"] = 0;
quantity_prices["one"] = 1;
quantity_prices["two"] = 2;
quantity_prices["three"] = 3;
quantity_prices["four"] = 4;
quantity_prices["five"] = 5;
quantity_prices["six"] = 6;
quantity_prices["seven"] = 7;
quantity_prices["eight"] = 8;
quantity_prices["nine"] = 9;
quantity_prices["ten"] = 10;


//This function finds the filling price based on the
//drop down selection
function getQuantityPrice() {
    var quantityPrice = 0;
    //Get a reference to the form id="foodform"
    var theForm = document.forms["foodform"];
    //Get a reference to the select id="filling"
    var selectedFilling = theForm.elements["quantity"];

    //set cakeFilling Price equal to value user chose
    //For example filling_prices["Lemon".value] would be equal to 5
    quantityPrice = quantity_prices[selectedFilling.value];

    //finally we return quantityPrice
    return quantityPrice;
}

// getExtraFilling() finds the price based if Extra stuff is selected or not.
function getExtraFilling() {
    var fill = document.getElementById('extra');

    if (fill.checked) {
        return (1);
    }
    else {
        return (0);
    }
}

//GET TOTAL 
function getTotal() {
    //Here we get the total price by calling our function
    //Each function returns a number so by calling them we add the values they return together
    var foodPrice = (getFoodSizePrice() * getQuantityPrice());
  
    //display the result
    document.getElementById('totalPrice').innerHTML =
        "Total Price R" + foodPrice;
 
}


/**
		*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
		*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
		
		var disqus_config = function () {
		this.page.url = "https://dutfoodview.disqus.com/Pie";  // Replace PAGE_URL with your page's canonical URL variable
		this.page.identifier = "disqus_thread_Pie"; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
		};
		
		(function() { // DON'T EDIT BELOW THIS LINE
		var d = document, s = d.createElement('script');
		s.src = 'https://dutfoodview.disqus.com/embed.js';
		s.setAttribute('data-timestamp', +new Date());
		(d.head || d.body).appendChild(s);
		})();


//AJAX Loading Calorie and Array Calorie Table
function loadDoc(url, cFunction) {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            cFunction(this);
        }
    };
    xhttp.open("GET", url, true);
    xhttp.send();
}

//Requesting SERVER(file) to get XML file and send it back to HTML Table.
function myFunction(xml) {
    // i varaible for for loop.
    var i = 0;

    //Array for storing xml data in Amount element.
    var Amount = [];
    var Title = [];

    //Get a reference to the form id="foodform"
    var theForm = document.forms["foodform"];
    //Get a reference to the select id="filling"
    var selectedFilling = theForm.elements["quantity"];

    var xmlDoc = xml.responseXML;
    var table = "<tr><th></th><th></th></tr>";
    //storing element Beef in XML to X variable
    var x = xmlDoc.getElementsByTagName("Pie");

    //populate Title and Amount Array from XML Data.
    for (var t = 0; t < x.length; t++) {
        Title.push(x[t].getElementsByTagName("Title")[0].childNodes[0].nodeValue);
        Amount.push(x[t].getElementsByTagName("Amount")[0].childNodes[0].nodeValue);
    }

    //populate array value from XML to Table HTML.
    for (i; i < x.length; i++) {
        table += "<tr><td>" + i + "</td>" + "<td>" +
            Title[i] +
            "</td><td>" +
            Amount[i] +
            "</td></tr>";
    }

    document.getElementById("Pie").innerHTML = table;
}

//CRUD Array
var Title1 = [];
var Amount1 = [];

//Requesting SERVER(file) to get XML file and send it back to HTML page under CRUD Output.
function myFunctionCRUD(xml) {

    var xmlDoc = xml.responseXML;
    //storing element Beef in XML to X variable
    var x = xmlDoc.getElementsByTagName("Pie");

    //populate Title and Amount Array from XML Data.
    for (var t = 0; t < x.length; t++) {
        Title1.push(x[t].getElementsByTagName("Title")[0].childNodes[0].nodeValue);
        Amount1.push(x[t].getElementsByTagName("Amount")[0].childNodes[0].nodeValue);
    }

    //OUTPUT NUMBER SYSTEM
    var i = 0;
    var numOut = [];
    for (i; i < Title1.length; i++) {
        numOut[i] = i;
    }

    //OUTPUT RESULT
    document.getElementById("OutputP").innerHTML = numOut;
    document.getElementById("OutputP1").innerHTML = Title1;
    document.getElementById("OutputP2").innerHTML = Amount1;
}


//UPDATE CRUD
function UpdateRow() {

    //INPUT values
    var num = document.getElementById("updateN").value;
    var titleH = document.getElementById("updateT").value;
    var valueH = document.getElementById("updateV").value;

    //GET current row to UPDATE
    //REPLACE calorie table with UPDATED values
    Title1[num] = titleH;
    Amount1[num] = valueH;

    //OUTPUT NUMBER SYSTEM
    var i = 0;
    var numOut = [];
    for (i; i < Title1.length; i++) {
        numOut[i] = i;
    }

    //OUTPUT RESULT
    document.getElementById("OutputP").innerHTML = numOut;
    document.getElementById("OutputP1").innerHTML = Title1;
    document.getElementById("OutputP2").innerHTML = Amount1;
}

//Delete 
function DeleteRow() {
    //input data from DELETE
    var del = document.getElementById("deleteT").value;

    //Delete specific row
    Title1.splice(del, 1, "");
    Amount1.splice(del, 1, "");

    //OUTPUT NUMBER SYSTEM
    var i = 0;
    var numOut = [];
    for (i; i < Title1.length; i++) {
        numOut[i] = i;

    }

    //OUTPUT RESULT
    document.getElementById("OutputP").innerHTML = numOut;
    document.getElementById("OutputP1").innerHTML = Title1;
    document.getElementById("OutputP2").innerHTML = Amount1;
}

//CREATE new data input 
function CreateNewData() {
    //input data from CREATE
    var inputC = document.getElementById("createT").value;
    var valueC = parseFloat(document.getElementById("createV").value);

    //CREATE new data
    Title1.splice(Title1.length, 0, inputC);
    Amount1.splice(Amount1.length, 0, valueC);

    //OUTPUT NUMBER SYSTEM
    var i = 0;
    var numOut = [];
    for (i; i < Title1.length; i++) {
        numOut[i] = i;

    }

    //OUTPUT RESULT
    document.getElementById("OutputP").innerHTML = numOut;
    document.getElementById("OutputP1").innerHTML = Title1;
    document.getElementById("OutputP2").innerHTML = Amount1;

}

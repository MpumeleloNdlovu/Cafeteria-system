
function BMICalculation() {
    //To store data from textbox
    var field1 = document.getElementById("weight").value;
	var field2 = document.getElementById("height").value;

	//to store a result from weight and height textbox
	var result = parseFloat(field1) / (parseFloat(field2) * 2);

	//to output the result of BMI
	if (!isNaN(result)) {
		document.getElementById("div-BMI-Result").innerHTML = "Your BMI result is: " + result.toLocaleString('en', { maximumSignificantDigits: 4 }) + " kg/m";
	}


	//to Produce the BMI Message
    if (result < 18.5) {
        document.getElementById("div-BMI-Result2").innerHTML = "Result is: " + "You are Underweight. ";
    }
    else if (result >= 18.5 && result <= 25) {
        document.getElementById("div-BMI-Result2").innerHTML = "Result is: " + "You have a Normal Weight. ";
    }
    else if (result > 25 && result < 30) {
        document.getElementById("div-BMI-Result2").innerHTML = "Result is: " + "You are Overweight. ";
    }
    else if (result > 30) {
        document.getElementById("div-BMI-Result2").innerHTML = "Result is: " + "You are Obese. ";
    }
	else
		alert("Please enter numbers in both textbox.");
	 
	 	////////////////////////
	 	//AJAX Loading BMI Table
	 	////////////////////////
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function () {
			if (this.readyState == 4 && this.status == 200) {
				myFunction(this);
			}
        };
        //get XML file for specific location.
        xhttp.open("GET", "XML/Underweight.xml", true);
		xhttp.send();
}

function myFunction(xml) {
    var i;
    var xmlDoc = xml.responseXML;
    var table = "<tr><th></th><th></th></tr>";
    var x = xmlDoc.getElementsByTagName("BMI");
    for (i = 0; i < x.length; i++) {
        table += "<tr><td>" +
            x[i].getElementsByTagName("scale")[0].childNodes[0].nodeValue +
            "</td><td>" +
            x[i].getElementsByTagName("result")[0].childNodes[0].nodeValue +
            "</td></tr>";
    }
    document.getElementById("underweight-table1").innerHTML = table;
}
	 